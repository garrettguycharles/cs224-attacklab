/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_145()
{
    return 1489898782U;
}

unsigned getval_194()
{
    return 3251079496U;
}

void setval_433(unsigned *p)
{
    *p = 3284633928U;
}

void setval_182(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_383(unsigned x)
{
    return x + 1208064419U;
}

void setval_326(unsigned *p)
{
    *p = 2428995928U;
}

unsigned getval_232()
{
    return 2425641178U;
}

unsigned addval_226(unsigned x)
{
    return x + 3821244504U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_269(unsigned x)
{
    return x + 2429995436U;
}

void setval_258(unsigned *p)
{
    *p = 3680556681U;
}

unsigned addval_489(unsigned x)
{
    return x + 3223377545U;
}

unsigned getval_452()
{
    return 3281114761U;
}

unsigned addval_180(unsigned x)
{
    return x + 3223377545U;
}

unsigned getval_287()
{
    return 3223377537U;
}

void setval_302(unsigned *p)
{
    *p = 3286272344U;
}

void setval_350(unsigned *p)
{
    *p = 3374891401U;
}

void setval_333(unsigned *p)
{
    *p = 3523791369U;
}

void setval_449(unsigned *p)
{
    *p = 3286288712U;
}

unsigned getval_155()
{
    return 3286272328U;
}

unsigned addval_131(unsigned x)
{
    return x + 3234122377U;
}

unsigned addval_113(unsigned x)
{
    return x + 3281043849U;
}

void setval_280(unsigned *p)
{
    *p = 3372275337U;
}

void setval_170(unsigned *p)
{
    *p = 3676359305U;
}

void setval_254(unsigned *p)
{
    *p = 3246998053U;
}

unsigned getval_460()
{
    return 3285633329U;
}

void setval_134(unsigned *p)
{
    *p = 3269495112U;
}

unsigned addval_486(unsigned x)
{
    return x + 3674259849U;
}

unsigned getval_166()
{
    return 2462747064U;
}

void setval_265(unsigned *p)
{
    *p = 3372796569U;
}

unsigned addval_288(unsigned x)
{
    return x + 3767093261U;
}

unsigned addval_411(unsigned x)
{
    return x + 3955343753U;
}

void setval_247(unsigned *p)
{
    *p = 3534015113U;
}

unsigned addval_245(unsigned x)
{
    return x + 2430635336U;
}

unsigned addval_323(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_128(unsigned x)
{
    return x + 3529556361U;
}

unsigned addval_400(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_297(unsigned x)
{
    return x + 3229925771U;
}

unsigned addval_264(unsigned x)
{
    return x + 3677929881U;
}

void setval_384(unsigned *p)
{
    *p = 3223374465U;
}

unsigned addval_463(unsigned x)
{
    return x + 3676359305U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
